self.__precacheManifest = [
  {
    "revision": "29eacf07ebfa98d78b08",
    "url": "/static/js/app.8b31a616.chunk.js"
  },
  {
    "revision": "66090dc4495d4ce3dfb9",
    "url": "/static/js/runtime~app.2e9f1821.js"
  },
  {
    "revision": "9793de934c5a7eb71676",
    "url": "/static/js/2.cacdbf6b.chunk.js"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "ca9ce9ff0676a9b04ef0f8a3ad17dd08",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "b49ae8ab2dbccb02c4d11caaacf09eab",
    "url": "/./fonts/Fontisto.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "b70cea0339374107969eb53e5b1f603f",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c39278f7abfc798a241551194f55e29f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "3c851d60ad5ef3f2fe43ebd263490d78",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "49a79d66bdea2debf1832bf4d7aca127",
    "url": "/./fonts/SpaceMono-Regular.ttf"
  },
  {
    "revision": "48c7ed4e7da9792af288a60d7242d615",
    "url": "/expo-service-worker.js"
  },
  {
    "revision": "1f2c209c51e50f9c92aa9f51d7a838e8",
    "url": "/index.html"
  },
  {
    "revision": "4197a9fd61e635cea7da7906870ef364",
    "url": "/register-service-worker.js"
  },
  {
    "revision": "ec543248d7b23864564429fc03837190",
    "url": "/serve.json"
  },
  {
    "revision": "8241cd11f057b5aea8b2af66ab2702e8",
    "url": "/static/js/2.cacdbf6b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "71033553ddc0843407efe54c23890fe2",
    "url": "/favicon-16.png"
  },
  {
    "revision": "c941078418f3ad7bb94a9ca94bc8b3dc",
    "url": "/favicon-32.png"
  },
  {
    "revision": "615280e83775685e49117729b227d0fc",
    "url": "/favicon.ico"
  },
  {
    "revision": "0ab22272906a19a70fdf5788b0ef5821",
    "url": "/manifest.json"
  }
];